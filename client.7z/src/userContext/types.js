export  const SET_RENDER = 'SET_RENDER';
export  const SEARCH_USER = 'SEARCH_USER';
export  const RELOAD = 'RELOAD';
export const CHANGESEARCH ="CHANGESEARCH";
export const GET_USER='GET_USER';