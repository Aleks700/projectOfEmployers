import React from 'react';
import Spinn from  '../img/Eclipse.svg';

export default function Spinner() {
    return (
        <div className="Spinner">
            <img src={Spinn} alt="Spinner"></img>
        </div>
    )
}
